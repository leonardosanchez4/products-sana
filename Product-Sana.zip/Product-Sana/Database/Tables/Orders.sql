﻿CREATE TABLE [dbo].[Orders]
(
	[Id] INT NOT NULL PRIMARY KEY,
	[IdCustomer] int,
	[dtOrder] datetime
)
