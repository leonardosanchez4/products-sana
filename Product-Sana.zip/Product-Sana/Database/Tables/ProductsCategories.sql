﻿CREATE TABLE [dbo].[ProductsCategories]
(
	[Id] INT NOT NULL PRIMARY KEY,
	[CategoryName] varchar(200)
)
